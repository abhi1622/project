package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capstore.bean.Merchant;
import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
import com.cg.capstore.dao.MerchantDao;
import com.cg.capstore.dao.OrdersDao;


@Component(value="merchantService")
public class MerchantService implements IMerchantService {
	@Autowired
	private OrdersDao orderDetailsRepo;
	@Autowired
	private MerchantDao merchantRepo;
	@Override
	public Orders deliveringProducts(int orderid) {
		
		
		Orders order=orderDetailsRepo.deliveringProducts(orderid);
		
		  if(order!=null) {
			  List<Product> products = order.getOrders_product();
//		  products.get(index).setInitial_quantity(products.get(index).getAvailable_quantity()-1);
		  order.setOrderStatus("Dispatched");
		  }
		 
		orderDetailsRepo.save(order);
		return order;
	}
		
		
	

}
