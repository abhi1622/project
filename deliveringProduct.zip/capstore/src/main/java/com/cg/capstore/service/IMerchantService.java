package com.cg.capstore.service;

import com.cg.capstore.bean.Orders;

public interface IMerchantService {
	public Orders deliveringProducts(int orderid);

}
