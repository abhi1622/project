package com.cg.capstore.dao;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.cg.capstore.bean.Orders;
@Transactional
@Configuration
@EnableTransactionManagement
@Repository
public interface OrdersDao  extends JpaRepository<Orders, String> {
	
	//@Query("from Order WHERE  customer.customerId=:custId")
	//public List<Orders> getOrdersForCustomer(@Param("custId") int custId);
	
	//@Query("from Order WHERE orderDate BETWEEN :fromDate AND :toDate")
	//public List<Orders> getOrdersBetween(Date fromDate, Date toDate);
	
	/*@Query(value="select * from Orders where order_id=?1",nativeQuery=true)
	public Orders deliveringProducts(String order_id);*/
	@Query(value="select * from orders",nativeQuery=true)
	public List<Orders> viewOrders();
	
}
