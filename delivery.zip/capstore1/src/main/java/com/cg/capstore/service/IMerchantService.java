package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;

public interface IMerchantService {
	

	public Orders deliveringProducts(String order_id);
	public List<Product> viewProducts();
}
