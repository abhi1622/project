package com.cg.capstore.service;


import java.time.Instant;
import java.time.LocalDate;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
import com.cg.capstore.dao.OrdersDao;
import com.cg.capstore.dao.ProductDao;


@Service("orderService")
public abstract class OrderService implements IOrderService {
	
    static String getAlphaNumericString(int n) 
    { 
  
        // chose a Character random from this String 
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                    + "0123456789"
                                    + "abcdefghijklmnopqrstuvxyz"; 
  
        // create StringBuffer size of AlphaNumericString 
        StringBuilder sb = new StringBuilder(n); 
  
        for (int i = 0; i < n; i++) { 
  
            // generate a random number between 
            // 0 to AlphaNumericString variable length 
            int index 
                = (int)(AlphaNumericString.length() 
                        * Math.random()); 
  
            // add Character one by one in end of sb 
            sb.append(AlphaNumericString 
                          .charAt(index)); 
        } 
  
        return sb.toString(); 
    } 

	@Autowired
	private OrdersDao orderDao;
	@Autowired
	private ProductDao productDao;
	
	public OrderService(OrdersDao orderDao) {
		super();
		this.orderDao = orderDao;
	}


	@Override
	public boolean checkAvailabilityInInventory(Product product) {//checking availability of ordered products
		if(product.getAvailable_quantity()<=0)
		{
			return false;
		}
		else
		{
			product.setAvailable_quantity(product.getAvailable_quantity()-1);
			
			return true;
		}
	}

	@Override
	public Product placeOrder(Product product) {
		Product newproduct=productDao.save(product);
		return newproduct;
	}

	@Override
	public boolean deliverOrderAndUpdateInventory(Orders order, Product product) {
	
		  String id=OrderService.getAlphaNumericString(20);
		  order.setOrder_id(id);
		  Date now=Date.from(Instant.now());
		  order.setPurchaseDate(now);
		  Date delivery=Date.from(Instant.MAX);
		  order.setDelivery_date(delivery);
		  order.setOrderStatus("Dispatched");
		  order.setSubTotal(product.getPrice());
		  orderDao.save(order);
		  return true;
	}
}




