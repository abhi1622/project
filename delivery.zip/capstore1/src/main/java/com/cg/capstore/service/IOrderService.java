package com.cg.capstore.service;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;

public interface IOrderService {


	public boolean checkAvailabilityInInventory(Product product);
	public Product placeOrder(Product product);
	public boolean deliverOrderAndUpdateInventory(Orders order,Product product);	
	
}