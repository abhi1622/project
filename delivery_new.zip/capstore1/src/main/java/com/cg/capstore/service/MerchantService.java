package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.capstore.bean.Orders;
import com.cg.capstore.bean.Product;
import com.cg.capstore.dao.MerchantDao;
import com.cg.capstore.dao.OrdersDao;
import com.cg.capstore.dao.ProductDao;


@Component(value="merchantService")
public abstract class MerchantService implements IMerchantService {
	@Autowired
	private OrdersDao ordersDao;
	@Autowired
	private MerchantDao merchantDao;
	@Autowired
	ProductDao productDao;
	@Override
	public Orders deliveringProducts(String order_id) {
		
		
		if(!ordersDao.existsById(order_id))
		{
			System.out.println("Order not present");
			return null;
		}
		else
		{
			Orders order = ordersDao.findById(order_id).get();
			order.setOrderStatus("DISPATCHED");
			ordersDao.saveAndFlush(order);
			return order;
		}
		/*
		//Orders order=ordersDao.deliveringProducts(order_id);
		Orders order=ordersDao.getOne(order_id);
		  if(order!=null) {
			  List<Product> products = order.getOrders_product();
//		  products.get(index).setInitial_quantity(products.get(index).getAvailable_quantity()-1);
		  order.setOrderStatus("Dispatched");
		  ordersDao.save(order);
		  return order;
		  }
		  else return null;
		 
		*/
		
	}
	public List<Product> viewProducts()
	{
		return productDao.viewAllProducts();
				
		
	}
	
	
	
	}
		
		
	


