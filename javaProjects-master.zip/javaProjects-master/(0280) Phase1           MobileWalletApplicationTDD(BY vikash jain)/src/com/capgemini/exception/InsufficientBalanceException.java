package com.capgemini.exception;

public class InsufficientBalanceException extends Exception {

}
