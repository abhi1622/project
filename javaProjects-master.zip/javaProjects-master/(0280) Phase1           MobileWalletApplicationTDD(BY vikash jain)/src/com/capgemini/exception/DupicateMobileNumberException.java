package com.capgemini.exception;

public class DupicateMobileNumberException extends Exception {

}
