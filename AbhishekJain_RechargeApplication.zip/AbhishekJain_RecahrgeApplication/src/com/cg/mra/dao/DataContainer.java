package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class DataContainer {

	static Map<String, Account> map;
	static Map<String, Account> createCollection(){
		//createCollection is method name to create collection via hashMap and if the key exist before then display the value of the key.
		if(map == null)
			map = new HashMap<String, Account>();
		//HashMap stores the value in the format of key->value pair which can be later be retrieved with the help of key. 
		return map;
	}

}
