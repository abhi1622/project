package com.cg.mra.beans;

public class Account {
	private String Mobileno;
	private String accountType;
	private String customerName;
	private double accountBalance;

	
//Parameterized Construction
	public Account(String mobileno, String accountType, String customerName, double accountBalance) {
		super();
		Mobileno = mobileno;
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}

	@Override // toString method  to print the variable value by just creation of object and passing in System.out.println(obj);
	public String toString() {
		return "Account [Mobileno=" + Mobileno + ", accountType=" + accountType + ", customerName=" + customerName
				+ ", accountBalance=" + accountBalance + "]";
	}

	public String getMobileno() {
		return Mobileno;
	}

	public void setMobileno(String mobileno) {
		Mobileno = mobileno;
	}
//Default Constructor
	public Account() {
		// TODO Auto-generated constructor stub
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	
	
}
