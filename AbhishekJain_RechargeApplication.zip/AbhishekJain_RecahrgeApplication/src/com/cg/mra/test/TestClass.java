package com.cg.mra.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class TestClass {
	
//	Testing all the possible cases for the method rechargeAmount
	
	AccountService as = new AccountServiceImpl();
	
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV2() throws MobileRechargeException{
		as.rechargeAccount("78945621", 123);
		as.rechargeAccount("7894581230", 0);
		as.rechargeAccount("8125407963", -45);
		
	}
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV3() throws MobileRechargeException{
		as.rechargeAccount("@@#^%", 45654);
		as.rechargeAccount(" ", -45643);
		as.rechargeAccount("	", -45643);
		as.rechargeAccount("afsfAAF#%#", -45643);
		as.rechargeAccount("", -45643);
		
		
	}
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV1() throws MobileRechargeException{
		
		as.rechargeAccount("8125407963", -45);
		
	}
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV5() throws MobileRechargeException{
		
		as.rechargeAccount("81254", -45);
		
	}
	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV6() throws MobileRechargeException{
		
		as.rechargeAccount("81254@#", -145);
		
	}


	@Test (expected = MobileRechargeException.class)
	public void TestOnRechargeAccountMethodV() throws MobileRechargeException{
		
		as.rechargeAccount("8125415215215151121", 20000);
		
	}



	
	
	@Test
	public void TestOnRechargeAccountMethodV8() throws MobileRechargeException{
		
	as.rechargeAccount("9010210131", 100);
	
    assertEquals(300,as.getAccountDetails("9010210131").getAccountBalance(),0.01);
		
	}
}
	
