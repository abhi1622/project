package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) throws MobileRechargeException {
		Scanner scanner = new Scanner(System.in);
		//Scanner class is used to take input from the user and scanner is the object of scanner class. 
		AccountService service = null;

		

		while(true) {
//			To display the menu again and again when the user enters valid number 
			System.out.println("1. Account Balance Enquiry \n2.Account Recharge \n3.Exit");
			

			int option = scanner.nextInt();

			switch (option) {
			case 1:
				//Case1: is to take inputs from the user and to validate the user inputs
				service = new AccountServiceImpl();
				
				System.out.println("Enter Mobile No: ");
				String mobNo = scanner.next();
				if(!service.validateMobNo(mobNo))
				{
					throw new MobileRechargeException("Wrong! phone number entered:: \n Please Enter a Valid Mobile Number");
				}
				Account acc = service.getAccountDetails(mobNo);
				
				System.out.println("Your Account details are: "+acc);
				System.out.println("Your current balance is: "+acc.getAccountBalance());

				break;

			case 2:
				//case2: is to take input from user and Recharges the account and display the current balance
				service = new AccountServiceImpl();
				
				System.out.println("Enter MobileNo: ");
				String mobileNo = scanner.next();
				if(!service.validateMobNo(mobileNo))
					throw new MobileRechargeException("Inavlid Mobile Number...");
				System.out.println("Enter Recharge Amount: ");
				double reAmt = scanner.nextDouble();
				if(!service.validateAmount(reAmt))
					throw new MobileRechargeException("Invalid amount entered...");
				
				service.rechargeAccount(mobileNo, reAmt);
				
				break;

			default:
			case 3:
				System.out.println("Exited...");
				System.exit(0);
				scanner.close();
				//We no longer use this scanner object so we close the object
				break;
			}

		}
		
	}

}
