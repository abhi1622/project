package com.capgemini.takehome.exception;

public class InvalidProductCodeException extends Exception{
public InvalidProductCodeException(String s) {
	super(s);
}
}
