package com.capgemini.takehome.exception;

public class ProductCodeIsNotValidException extends Exception{
public ProductCodeIsNotValidException(String s) {
	super(s);
}
}
